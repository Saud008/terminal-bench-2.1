#!/usr/bin/env bash
set -euo pipefail

cd /app

cat > internal/engine/implicit.go <<'IMPLICIT_GO'
package engine

import (
	"os"
	"sort"
	"strings"

	"brickmake/internal/db"
	"brickmake/internal/expand"
	"brickmake/internal/text"
)

// maxChain bounds implicit rule chains.
const maxChain = 16

// match is the result of implicit rule search for one target.
type match struct {
	rule      *db.PatternRule
	stem      string // $*, including the directory part
	normal    []string
	orderOnly []string
	also      []string // the rule's other targets
	inter     map[string]*match
}

type candidate struct {
	rule   *db.PatternRule
	target int
	dir    string // directory prepended to the stem, if any
	stem   string // the part matched by '%'
}

func (c candidate) fullStem() string { return c.dir + c.stem }

// candidates lists the pattern rules whose target pattern matches name,
// shortest stem first; rules of equal stem length keep makefile order. A
// target pattern without a slash is matched against the file part of a
// name that has a directory, and the directory becomes part of the stem.
func (e *Engine) candidates(name string, used map[*db.PatternRule]bool) []candidate {
	dir, base := text.SplitDir(name)
	var cs []candidate
	for _, r := range e.db.PatternRules {
		if used[r] {
			continue
		}
		for ti, tp := range r.Targets {
			if tp == "%" {
				continue
			}
			var stem string
			var ok bool
			d := ""
			if dir == "" || strings.IndexByte(tp, '/') >= 0 {
				stem, ok = text.Match(tp, name)
			} else {
				stem, ok = text.Match(tp, base)
				d = dir
			}
			if !ok || stem == "" {
				continue
			}
			cs = append(cs, candidate{rule: r, target: ti, dir: d, stem: stem})
			break
		}
	}
	sort.SliceStable(cs, func(i, j int) bool {
		return len(cs[i].fullStem()) < len(cs[j].fullStem())
	})
	return cs
}

// prereqs computes a candidate's prerequisite names. The directory of a
// directory-relative match is prepended to every prerequisite that
// contains '%'.
func (e *Engine) prereqs(c candidate, name string, sc *expand.Scope) (normal, orderOnly []string) {
	pr := c.rule.Prereqs
	normal, orderOnly = pr.Normal, pr.OrderOnly
	if pr.Second {
		s := &expand.Scope{Auto: &expand.Auto{Target: name, Stem: c.fullStem()}}
		if sc != nil {
			s.Sets = sc.Sets
		}
		e.x.Pos = c.rule.Pos
		normal, orderOnly = text.SplitOrder(text.Fields(e.x.Expand(pr.Text, s)))
	}
	conv := func(words []string) []string {
		out := make([]string, len(words))
		for i, w := range words {
			if strings.IndexByte(w, '%') < 0 {
				out[i] = w
			} else {
				out[i] = c.dir + text.Subst(w, c.stem)
			}
		}
		return out
	}
	return conv(normal), conv(orderOnly)
}

// oughtToExist reports whether a prerequisite exists or is mentioned in
// the makefile.
func (e *Engine) oughtToExist(name string) bool {
	if e.db.Lookup(name) != nil {
		return true
	}
	_, err := os.Stat(name)
	return err == nil
}

// findImplicit searches the pattern rules for name. The first pass accepts
// a rule whose prerequisites all exist or ought to exist; the second pass
// also accepts prerequisites that can be made by a chain of other pattern
// rules.
func (e *Engine) findImplicit(name string, sc *expand.Scope, depth int, used map[*db.PatternRule]bool) *match {
	type tried struct {
		c              candidate
		normal, orders []string
	}
	var ts []tried
	for _, c := range e.candidates(name, used) {
		n, o := e.prereqs(c, name, sc)
		ts = append(ts, tried{c, n, o})
	}
	all := func(t tried) []string { return append(append([]string{}, t.normal...), t.orders...) }
	for _, t := range ts {
		good := true
		for _, p := range all(t) {
			if !e.oughtToExist(p) {
				good = false
				break
			}
		}
		if good {
			return newMatch(t.c, t.normal, t.orders, nil)
		}
	}
	if depth >= maxChain {
		return nil
	}
	for _, t := range ts {
		inter := map[string]*match{}
		good := true
		for _, p := range all(t) {
			if e.oughtToExist(p) {
				continue
			}
			next := map[*db.PatternRule]bool{t.c.rule: true}
			for r := range used {
				next[r] = true
			}
			m := e.findImplicit(p, nil, depth+1, next)
			if m == nil {
				good = false
				break
			}
			inter[p] = m
		}
		if good {
			return newMatch(t.c, t.normal, t.orders, inter)
		}
	}
	return nil
}

func newMatch(c candidate, normal, orderOnly []string, inter map[string]*match) *match {
	m := &match{rule: c.rule, stem: c.fullStem(), normal: normal, orderOnly: orderOnly, inter: inter}
	for i, tp := range c.rule.Targets {
		if i != c.target {
			m.also = append(m.also, c.dir+text.Subst(tp, c.stem))
		}
	}
	return m
}

// implicitFor runs implicit rule search once for a file without a recipe.
func (e *Engine) implicitFor(n *node) {
	if n.searched {
		return
	}
	n.searched = true
	if r := n.f.RecipeRule(); r != nil {
		n.recipe = r.Recipe
		if r.Static {
			n.stem = r.Stem
		}
		return
	}
	if n.f.Phony {
		return
	}
	m := n.preset
	if m == nil {
		m = e.findImplicit(n.name(), e.scope(n), 0, map[*db.PatternRule]bool{})
	}
	if m == nil {
		return
	}
	n.match = m
	n.recipe = m.rule.Recipe
	n.stem = m.stem
	for _, p := range append(append([]string{}, m.normal...), m.orderOnly...) {
		created := e.db.Lookup(p) == nil
		pn := e.node(e.db.Enter(p))
		if sub := m.inter[p]; sub != nil && created {
			pn.intermediate = true
			pn.preset = sub
		}
	}
}
IMPLICIT_GO

cat > internal/engine/scope.go <<'SCOPE_GO'
package engine

import (
	"sort"

	"brickmake/internal/db"
	"brickmake/internal/expand"
	"brickmake/internal/text"
	"brickmake/internal/vars"
)

// patternSet collects the pattern-specific variables whose pattern matches
// the file into one set. Definitions are applied from the shortest pattern
// to the longest (definitions of equal length in makefile order), so the
// most specific pattern is applied last.
func (e *Engine) patternSet(n *node) *vars.Set {
	if n.patReady {
		return n.patVars
	}
	n.patReady = true
	var hits []*db.PatternVar
	for _, pv := range e.db.PatternVars {
		if _, ok := text.Match(pv.Pattern, n.name()); ok {
			hits = append(hits, pv)
		}
	}
	if len(hits) == 0 {
		return nil
	}
	sort.SliceStable(hits, func(i, j int) bool { return len(hits[i].Pattern) < len(hits[j].Pattern) })
	set := vars.NewSet()
	for _, pv := range hits {
		e.x.Pos = pv.Pos
		e.x.DefinePattern(set, pv.Name, pv.Op, pv.Value, pv.Pos)
	}
	n.patVars = set
	return set
}

// scope is the variable context of a file: its own target-specific
// variables, then its pattern-specific variables, then the context of the
// target that first asked for it, and finally the global variables.
func (e *Engine) scope(n *node) *expand.Scope {
	sc := &expand.Scope{}
	for x := n; x != nil; x = x.parent {
		sc.Sets = append(sc.Sets, x.f.Vars)
		if ps := e.patternSet(x); ps != nil {
			sc.Sets = append(sc.Sets, ps)
		}
	}
	return sc
}
SCOPE_GO

/usr/local/go/bin/gofmt -l . | tee /tmp/gofmt.out
test ! -s /tmp/gofmt.out
/usr/local/go/bin/go vet ./...
/usr/local/go/bin/go build -o /tmp/brickmake ./cmd/brickmake
