#pragma once
int foo_answer(void);
