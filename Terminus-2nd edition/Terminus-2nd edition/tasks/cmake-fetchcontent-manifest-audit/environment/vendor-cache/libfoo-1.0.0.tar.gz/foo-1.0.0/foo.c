int foo_answer(void){return 42;}
