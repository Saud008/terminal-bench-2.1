#pragma once
int bar_answer(void);
