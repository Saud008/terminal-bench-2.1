int bar_answer(void){return 7;}
