int baz_answer(void){return 99;}
