#pragma once
int baz_answer(void);
