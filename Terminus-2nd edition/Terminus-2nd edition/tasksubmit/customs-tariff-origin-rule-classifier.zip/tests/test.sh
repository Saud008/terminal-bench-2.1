#!/usr/bin/env bash
set -euo pipefail

mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

if [ "$PWD" = "/" ]; then
  echo "Error: No working directory set. Please set a WORKDIR in your Dockerfile."
  exit 1
fi

# Compiled stack: go build refresh via verifier-rebuild.sh before pytest.
set +e
bash /app/scripts/verifier-rebuild.sh && /opt/verifier-venv/bin/python -m pytest -o cache_dir=/tmp/pytest_cache \
      --ctrf /logs/verifier/ctrf.json \
      "/tests/test_outputs.py" \
      "/tests/test_origin_atlas.py" \
      "/tests/test_hs_policy.py" \
      "/tests/test_tb3_origin.py" -rA
rc=$?
if [ "$rc" -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
