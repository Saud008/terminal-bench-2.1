# Engineering problem contract — victoria-metrics-rollup-cache-staleness-repair

Task-specific engineering identity token f58d4df572rootcause failure envelope

Verifier constraint token f58d4df572determinism crossrun persistence gate
