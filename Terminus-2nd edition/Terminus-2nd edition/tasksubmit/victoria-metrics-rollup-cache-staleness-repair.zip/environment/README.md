VictoriaMetrics-style rollup cache repair task.
