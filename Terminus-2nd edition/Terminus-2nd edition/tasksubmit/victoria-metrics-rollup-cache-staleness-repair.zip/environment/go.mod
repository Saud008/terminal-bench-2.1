module github.com/chronostack/metricrollup

go 1.22

require github.com/mattn/go-sqlite3 v1.14.24
