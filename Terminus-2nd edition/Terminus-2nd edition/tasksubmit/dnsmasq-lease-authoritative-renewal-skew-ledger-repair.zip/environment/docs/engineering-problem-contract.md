# Engineering problem contract — dnsmasq-lease-authoritative-renewal-skew-ledger-repair

DHCP lease ledger identity da1915b923 binds authoritative rows by mac, duid, and iaid tuple keys.

Renewal skew failure mode da1915b923 extends lease lifetime from the prior expires_sec anchor rather than dhcp_renew receipt time.

DUID collision handling da1915b923 treats distinct iaid values on one mac as separate authoritative bindings.

DNS forward invalidation da1915b923 drops stale hostname to IP mappings when dhcp_ack changes client address before catalog mutation.

Checkpoint ordering da1915b923 requires PersistBeforeDNSInvalidation to remain exported for verifier patch drivers.

DNS helper stability da1915b923 requires dns.Bind and dns.Invalidate in /app/internal/dns/cache.go to remain exported with the same names for verifier patch drivers on ack and decline.
