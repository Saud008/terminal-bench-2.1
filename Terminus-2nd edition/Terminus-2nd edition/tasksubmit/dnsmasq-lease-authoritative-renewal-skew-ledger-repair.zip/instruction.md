Task identity da1915b923 anchors this DHCP lease skew ledger repair. See /app/docs/engineering-problem-contract.md for mac-duid-iaid, renewal anchor, and DNS forward invalidation rules.

The dnsmasqledger command at /app/cmd/dnsmasqledger reads JSONL dhcp event logs, maintains authoritative lease rows and tentative offers, and writes lease-report.json plus SQLite rows at /app/work/leases.db. Bundled dhcp logs under /app/fixtures/replay/ disagree with /app/docs/ contracts today.

Align Go sources under /app/internal/ so dhcp replay matches:

- /app/docs/dhcp-replay-schema.md
- /app/docs/lease-contract.md
- /app/docs/dns-forward-cache.md
- /app/docs/staging-schema.md
- /app/docs/ingest-export-pipeline.md
- /app/docs/fixture-catalog.md

Each replay run must write /app/state/lease-snapshot.json during ingest, persist leases to /app/work/leases.db, and emit /app/output/lease-report.json that an independent reference can recompute from the same log. DNS forward entries must reflect only current authoritative bindings after IP changes.

Example:

dnsmasqledger replay --log /app/fixtures/replay/001-base.jsonl --output /app/output/lease-report.json --db /app/work/leases.db

When TB3_REPLAY_DIR is set to an absolute directory, replay logs are read from that directory instead of /app/fixtures/replay/. Rebuild dnsmasqledger from /app after editing sources before validating replay output. Do not edit /app/docs/, /app/fixtures/, or /app/cmd/.

VERIFIER_SEED may be set for procedural MAC mutation tests; when unset the verifier uses dnsmasq-lease-seed-8.

Structural edit constraints required by verification:

- Keep the exported PersistBeforeDNSInvalidation function in /app/internal/checkpoint/store.go. Verification rebuilds with patch drivers that still call this symbol; do not delete it even if your replay driver changes make it appear unused.
- Keep the exported dns.Bind and dns.Invalidate functions in /app/internal/dns/cache.go. Verification patch drivers for ack and decline still import and call these symbols; do not rename or remove them even if you inline equivalent logic elsewhere.
- Do not add new Go source files under /app/internal/lease/. Repair only the existing lease package files (ack.go, decline.go, offer.go, renew.go).
