        use crate::m04::IndexRow;
        use serde::{Deserialize, Serialize};
        use sha2::{Digest, Sha256};
        use std::fs;
        use std::path::Path;

        #[derive(Debug, Clone, Serialize, Deserialize)]
        pub struct SnapshotDoc {
            pub run_id: String,
            pub scenario: String,
            pub target_python: String,
            pub target_platform: String,
            pub target_arch: String,
            pub index_fingerprint: String,
            pub packages: Vec<IndexRow>,
            pub queries: Vec<QueryRow>,
            pub snapshot_digest: String,
        }

        #[derive(Debug, Clone, Serialize, Deserialize)]
        pub struct QueryRow {
            pub package: String,
            pub spec: String,
        }

        pub fn snapshot_digest(
            run_id: &str,
            fp: &str,
            _python: &str,
            _platform: &str,
            _arch: &str,
            packages: &[IndexRow],
        ) -> String {
            // NOTE: digest input fields per snapshot-resolution-schema.md
            let body = serde_json::json!({
                "run_id": run_id,
                "index_fingerprint": fp,
                "packages": packages.iter().map(|p| serde_json::json!({"package": p.package, "version": p.version})).collect::<Vec<_>>()
            });
            let raw = serde_json::to_string(&body).unwrap_or_default();
            hex::encode(Sha256::digest(raw.as_bytes()))
        }

        pub fn write_snapshot(path: &Path, doc: &SnapshotDoc) -> Result<(), String> {
            let json = serde_json::to_string_pretty(doc).map_err(|e| e.to_string())?;
            fs::write(path, format!("{json}
")).map_err(|e| e.to_string())
        }

        mod hex {
            pub fn encode(bytes: impl AsRef<[u8]>) -> String {
                bytes.as_ref().iter().map(|b| format!("{b:02x}")).collect()
            }
        }
