"""SHA-256 helper shared by the salted-id and atlas-digest derivations."""

from __future__ import annotations

import hashlib


def sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
