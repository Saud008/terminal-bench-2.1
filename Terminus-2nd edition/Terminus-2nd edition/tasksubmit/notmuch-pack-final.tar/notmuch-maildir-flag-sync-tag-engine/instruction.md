Build the mailsync CLI under /app so operators can ingest Maildir trees into a staging snapshot, synchronize notmuch-style tags with Maildir :2, flag letters and SQLite, and publish export reports without rescanning disk. The Go tree under /app/cmd/mailsync and /app/internal/ must satisfy every contract in /app/docs/staging-snapshot.md, /app/docs/snapshot-publish-bridge.md, /app/docs/tag-precedence.md, /app/docs/message-id-dedupe.md, /app/docs/maildir-flag-order.md, /app/docs/sync-transaction-order.md, and /app/docs/export-schema.md.

mailsync ingest --maildir PATH --db PATH scans cur and new (never tmp), writes /app/state/mail-sync.snapshot.json and must not rename files or write /app/output/mail-sync-report.json

mailsync sync --maildir PATH --db PATH --report PATH runs the full ingest-to-export pipeline: staging snapshot, dedupe, thread binding, tag merge, SQLite commit before maildir renames, flag suffix updates, and JSON report emission.

mailsync publish --db PATH --report PATH re-exports from the database plus the on-disk staging snapshot without rescanning the maildir or renaming files.

Use --maildir or TB3_MAILDIR when set to an absolute maildir root for verifier-only trees. Rebuild with go build -mod=readonly -o /usr/local/bin/mailsync ./cmd/mailsync. Do not edit /app/docs/, /app/fixtures/sources/, /opt/verifier-fixtures/sources/, or /tests/.

The export/wrap.go helper is legacy metadata decoration and is not on the sync publish hot path.
