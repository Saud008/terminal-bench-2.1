# mailsync

Offline Maildir + notmuch tag binding repair task. Contracts live under `/app/docs/`. Bundled maildir fixtures are under `/app/fixtures/maildir/`.
