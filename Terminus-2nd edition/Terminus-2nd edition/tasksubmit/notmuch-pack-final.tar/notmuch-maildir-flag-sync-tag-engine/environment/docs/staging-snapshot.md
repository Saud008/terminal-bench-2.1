# Staging snapshot

`mailsync ingest` writes `/app/state/mail-sync.snapshot.json` (override path via snapshot only for tests).

## Schema

```json
{
  "sync_version": 1,
  "staging_epoch": 0,
  "maildir_root": "/app/fixtures/maildir",
  "db_path": "/app/data/mailsync.db",
  "maildir_files_seen": 0,
  "messages_in": 0,
  "messages_skipped": 0,
  "entries": [
    {
      "message_id": "<id@example.com>",
      "maildir_relpath": "cur/1500.example:2,RS",
      "flags": "RS",
      "x_keywords": ["work", "urgent"],
      "mtime_ns": 0,
      "subject": "example"
    }
  ]
}
```

`x_keywords` must preserve parsed X-Keywords header tokens (lowercased). Do not drop the header during ingest.

`staging_epoch` mirrors `sync_meta.staging_epoch` at write time. Only `sync` increments the epoch after commit; see sync-transaction-order.md and snapshot-publish-bridge.md.

`entries` are sorted by `message_id` ascending.
