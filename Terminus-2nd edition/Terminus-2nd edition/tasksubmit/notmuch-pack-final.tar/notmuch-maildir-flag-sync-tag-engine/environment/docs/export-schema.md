# Export report schema

`mailsync sync` and `mailsync publish` write JSON with:

```json
{
  "sync_version": 1,
  "staging_epoch": 0,
  "maildir_files_seen": 0,
  "messages_indexed": 0,
  "messages_skipped": 0,
  "duplicates_merged": 0,
  "flag_renames": 0,
  "tag_writes": 0,
  "threads_resolved": 0,
  "commit_before_rename": true,
  "messages": [
    {
      "message_id": "<id@example.com>",
      "thread_id": "t-root@example.com",
      "maildir_relpath": "cur/1500.example:2,RS",
      "flags": "RS",
      "tags": ["replied", "seen", "work"],
      "keywords_source": "x-keywords"
    }
  ]
}
```

`messages` length equals `messages_indexed`. Sort `messages` by `message_id` ascending. `tags` are lowercased, deduplicated, sorted lexicographically.

`flag_renames` counts Maildir files whose `:2,FLAGS` suffix changed during sync.
