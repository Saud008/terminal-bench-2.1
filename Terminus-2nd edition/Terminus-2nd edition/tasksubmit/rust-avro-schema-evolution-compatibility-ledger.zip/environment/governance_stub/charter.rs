// governance charter placeholder
