        #!/usr/bin/env bash
        set -euo pipefail

        match_rule_for_path() {
          local path="$1"
          local cascaded_json="$2"
          python3 - <<'PY' "$path" "$cascaded_json"
import json, fnmatch, sys
path = sys.argv[1]
rules = json.loads(sys.argv[2])
picked = {"transfer": "include", "matched_rule_index": -1, "token": ""}
for row in rules:
    pat = row["pattern"]
    if pat.startswith("/"):
        hit = fnmatch.fnmatch(path, pat[1:])
    else:
        hit = fnmatch.fnmatch(path, pat) or fnmatch.fnmatch(path.split("/")[-1], pat)
    if hit:
        token = row["token"]
        transfer = "exclude" if token == "-" else "include"
        picked = {"transfer": transfer, "matched_rule_index": row["index"], "token": token}
print(json.dumps(picked))
PY
        }
