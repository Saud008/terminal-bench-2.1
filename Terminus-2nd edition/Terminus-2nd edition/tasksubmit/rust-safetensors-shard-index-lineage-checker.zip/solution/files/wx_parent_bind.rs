use crate::wx_bundle_read::ManifestDoc;

fn normalize_lineage_hash(raw: &str) -> String {
    let trimmed = raw.trim();
    let body = if let Some(rest) = trimmed.strip_prefix("0x") {
        rest
    } else if let Some(rest) = trimmed.strip_prefix("0X") {
        rest
    } else {
        trimmed
    };
    body.to_ascii_lowercase()
}

pub fn wx_anchor_fold(doc: &ManifestDoc) -> bool {
    normalize_lineage_hash(&doc.base_model_hash)
        == normalize_lineage_hash(&doc.expected_base_model_hash)
}
