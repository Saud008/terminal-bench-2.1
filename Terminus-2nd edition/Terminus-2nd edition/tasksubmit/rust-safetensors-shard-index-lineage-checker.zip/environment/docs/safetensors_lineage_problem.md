# Engineering problem contract

xr7 validates multi-shard safetensors weight catalogs for ML release governance. Unlike chunked array consolidators, this tool reasons about binary tensor headers, LoRA parent hash binding (including optional `0x` prefixes), payload-relative offset windows, and per-tensor payload fingerprints. Catalog scan must fail closed on payload overflows. Atlas publish expands failed lineage into `LINEAGE_HASH` plus per-row `LINEAGE_ROW` markers with a stable tensor-then-code sort.
