# Adapter lineage hashes

Manifest `base_model_hash` must match `expected_base_model_hash` after normalization:

1. Trim ASCII whitespace.
2. If the value begins with `0x` or `0X`, strip that prefix once.
3. Compare the remaining hex body with ASCII case-insensitive equality.

Mixed-case hex and optional `0x`/`0X` prefixes refer to the same lineage identity. Do not require the prefix to be present on both sides.
