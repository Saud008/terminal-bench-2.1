# Shard payload fingerprint

Fingerprints are SHA-256 digests encoded as lowercase hex.

Hash only the payload byte slice `payload[start:end]` where `start`/`end` are the safetensors `data_offsets` values. Those offsets are relative to the start of the payload section that follows the eight-byte length prefix and JSON header. Do not treat `data_offsets` as absolute positions from the beginning of the file, and do not include the length prefix or JSON header bytes in the digest input.
