# Hidden fixture override

When `XR7_CATALOG_ROOT` and `XR7_WEIGHT_ROOT` point at alternate directories, catalog scan and atlas publish must preserve the same journal fields, report shape, lineage normalization, fingerprint scope, offset rules, and violation sort order as bundled fixtures.

Alternate roots may include deliberately failing lineage catalogs and multi-shard manifests. Payload-relative overflow catalogs must make `catalog-scan` fail closed rather than journal truncated windows.
