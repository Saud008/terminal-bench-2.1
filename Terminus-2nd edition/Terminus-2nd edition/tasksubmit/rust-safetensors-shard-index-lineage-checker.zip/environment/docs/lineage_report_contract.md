# Lineage report contract

Atlas publish emits a JSON array with one object per catalog manifest, in the same lexicographic manifest filename order used by catalog scan.

Each object contains:

- `manifest_id`
- `violations`: array of `{tensor, code, message}`
- `totals.violation_count`: equals `len(violations)`
- `totals.tensor_count`: equals the number of journal rows for that manifest

## Violation emission

When normalized lineage hashes do not match, emit:

1. One `LINEAGE_HASH` violation with `tensor` set to `*` and message `base_model_hash does not match expected`.
2. One `LINEAGE_ROW` violation per journal row for that manifest, using that row's tensor name and message `tensor row inherits failed lineage bind`.

Also emit `MISSING_TENSOR`, `OFFSET_OVERFLOW`, `DTYPE_SHAPE`, `DIGEST`, and `PARSE_FAIL` as produced by atlas re-validation of staged rows against shard bytes.

## Sort order

Sort `violations` by `tensor` ascending, then by `code` ascending (lexicographic). Sorting by `code` first is incorrect.
