# Offset bounds validation

For each tensor, `data_offsets[1]` (end) must be less than or equal to the payload section length. The payload section length equals `file_size - 8 - header_json_length`.

Reject tensors whose end offset would read past the payload slice even when the end is still inside the overall file because of the length prefix and header bytes. Comparing against the whole file size is incorrect.
