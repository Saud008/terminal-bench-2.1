# Weight audit flow

Catalog scan walks manifest JSON files in lexicographic filename order, validates each tensor against safetensors shard bytes, and appends rows to `/app/var/xr7_journal.ndjson`.

`run_seq` is a single counter for the entire catalog-scan batch: it starts at `0` and increments by one for every journaled tensor across all manifests and shards. It must not restart per manifest or per shard.

Atlas publish reads the journal plus the same catalog and weight roots to emit `/app/lineage/weight_lineage_atlas.json` with deterministic violation emission and sort rules from `lineage_report_contract.md`.
