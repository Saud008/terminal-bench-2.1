use crate::wx_bundle_read::ManifestDoc;

pub fn wx_anchor_fold(doc: &ManifestDoc) -> bool {
    // BUG: ASCII case fold only — does not strip optional 0x / 0X hex prefix.
    doc.base_model_hash.to_ascii_lowercase() == doc.expected_base_model_hash.to_ascii_lowercase()
}
