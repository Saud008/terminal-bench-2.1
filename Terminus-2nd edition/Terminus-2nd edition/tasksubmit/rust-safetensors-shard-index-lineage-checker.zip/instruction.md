# Model weight lineage atlas

ML platform operators need a reproducible weight lineage atlas from safetensors shard catalogs before adapters ship to production. The Rust package under `/app/environment` provides the `xr7` release CLI. Specs live under `/app/docs/` (see Required reading).

## CLI contract

### `catalog-scan`

Inputs:
- `--catalog-dir`: directory of catalog JSON manifests (default fixtures: `/app/environment/registry/catalogs`)
- `--weight-root`: directory of `.safetensors` shard files (default fixtures: `/app/environment/registry/weights`)
- `--journal`: output path for validation rows (must be `/app/var/xr7_journal.ndjson` for graded runs)

Behavior:
- Walk catalog JSON in lexicographic filename order.
- For each tensor, validate payload-relative `data_offsets`, dtype/shape byte sizing (including BF16 = 2 bytes), and payload-only fingerprints per the docs.
- Compare LoRA lineage hashes after optional `0x`/`0X` prefix stripping and ASCII case-insensitive compare.
- Assign a globally monotonic `run_seq` starting at `0` across the full batch (not per manifest or shard).
- Fail closed when an offset window exceeds the payload section even if the end is still inside the file.
- Write one NDJSON object per validated tensor to the journal path.

### `atlas-publish`

Inputs:
- `--journal`: journal produced by `catalog-scan`
- `--catalog-dir` / `--weight-root`: same roots used for the scan
- `--atlas`: output path (must be `/app/lineage/weight_lineage_atlas.json` for graded runs)

Behavior:
- Emit a JSON array with one object per catalog manifest (same lexicographic order).
- On failed lineage bind, emit `LINEAGE_HASH` (`tensor` = `*`) plus one `LINEAGE_ROW` per journal row for that manifest.
- Re-validate staged rows against shard bytes (`MISSING_TENSOR`, `OFFSET_OVERFLOW`, `DTYPE_SHAPE`, `DIGEST`, `PARSE_FAIL` as applicable).
- Sort violations by `tensor` then `code`.
- Set `totals.violation_count` to `len(violations)` and `totals.tensor_count` to journal rows for that manifest.

## Environment overrides

`XR7_CATALOG_ROOT` and `XR7_WEIGHT_ROOT` may replace the default catalog and weight roots. Behavior and output shape must match the contracts above. An off-path metric wrapper module is not required for scan or publish.

## Required reading

- `/app/docs/weight_audit_flow.md`
- `/app/docs/manifest_format.md`
- `/app/docs/safetensors_layout.md`
- `/app/docs/span_guard.md`
- `/app/docs/elem_layout_rules.md`
- `/app/docs/payload_fingerprint.md`
- `/app/docs/parent_hash_bind.md`
- `/app/docs/lineage_report_contract.md`
- `/app/docs/hidden_fixture_override.md`
- `/app/docs/safetensors_lineage_problem.md`
