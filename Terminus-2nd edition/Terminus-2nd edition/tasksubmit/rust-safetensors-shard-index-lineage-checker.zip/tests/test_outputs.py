"""Pytest entrypoint for the safetensors shard index contract suite."""
from __future__ import annotations

import os
from pathlib import Path

from xr7_ref_harness import (
    catalog_dir,
    load_journal_rows,
    pipeline,
    rebuild,
    weight_root,
)
from xr7_ref_math import reference_journal

ATLAS = Path("/app/lineage/weight_lineage_atlas.json")
JOURNAL = Path("/app/var/xr7_journal.ndjson")


def _assert_real_nonempty(path: Path) -> bytes:
    """Reject symlinks and empty stubs for graded outputs (O_NOFOLLOW)."""
    assert not path.is_symlink(), f"graded output must not be a symlink: {path}"
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    fd = os.open(path, flags)
    try:
        data = os.read(fd, 1 << 27)
    finally:
        os.close(fd)
    assert data, f"graded output is empty: {path}"
    return data


def reference_shard_journal(catalogs=None, weights=None):
    """Independent reference helper exposed from the verifier entrypoint."""
    c = Path(catalogs) if catalogs else catalog_dir()
    w = Path(weights) if weights else weight_root()
    return reference_journal(c, w)


def test_reference_helper_smoke_row_count():
    """The verifier entrypoint must expose an independent reference helper."""
    rebuild()
    pipeline()
    got = load_journal_rows()
    ref = reference_shard_journal()
    assert len(got) == len(ref)


def test_entrypoint_writes_lineage_report_path():
    """Atlas JSON must exist as a real non-empty file after publish."""
    rebuild()
    pipeline()
    data = _assert_real_nonempty(ATLAS)
    assert data.lstrip().startswith(b"[")


def test_entrypoint_writes_shard_journal_path():
    """Journal NDJSON must exist as a real non-empty file after scan."""
    rebuild()
    pipeline()
    data = _assert_real_nonempty(JOURNAL)
    assert b"manifest_id" in data
