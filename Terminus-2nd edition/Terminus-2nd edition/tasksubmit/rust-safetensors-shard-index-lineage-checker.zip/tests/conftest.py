import sys
from pathlib import Path

# Verifier helpers live alongside the contract tests (not in the agent image).
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
