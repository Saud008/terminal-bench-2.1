#!/bin/bash
set -euo pipefail

if [ "$PWD" = "/" ]; then
    echo "Error: No working directory set. Please set a WORKDIR in your Dockerfile."
    exit 1
fi

# Install verifier-only probe fixtures (not present in the agent image tree).
mkdir -p /opt/verifier-fixtures/xr7_probe/catalogs /opt/verifier-fixtures/xr7_probe/weights \
  /opt/verifier-fixtures/xr7_probe_reject/catalogs /opt/verifier-fixtures/xr7_probe_reject/weights
if [ -d /tests/data/xr7_probe/catalogs ]; then
  cp -a /tests/data/xr7_probe/catalogs/. /opt/verifier-fixtures/xr7_probe/catalogs/
fi
if [ -d /tests/data/xr7_probe/weights ]; then
  cp -a /tests/data/xr7_probe/weights/. /opt/verifier-fixtures/xr7_probe/weights/
fi
if [ -d /tests/data/xr7_probe_reject/catalogs ]; then
  cp -a /tests/data/xr7_probe_reject/catalogs/. /opt/verifier-fixtures/xr7_probe_reject/catalogs/
fi
if [ -d /tests/data/xr7_probe_reject/weights ]; then
  cp -a /tests/data/xr7_probe_reject/weights/. /opt/verifier-fixtures/xr7_probe_reject/weights/
fi

set +e
cd /app/environment && mkdir -p /app/bin && cargo build --release --locked && install -m 0755 target/release/xr7 /app/bin/xr7 && pytest --ctrf /logs/verifier/ctrf.json /tests/test_outputs.py /tests/test_xr7_contract.py -rA
if [ $? -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi
