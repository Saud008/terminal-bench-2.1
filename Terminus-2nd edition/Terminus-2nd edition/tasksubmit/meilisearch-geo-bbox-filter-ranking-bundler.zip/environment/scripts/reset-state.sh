#!/usr/bin/env bash
set -euo pipefail
rm -rf /app/state /app/output /app/work
mkdir -p /app/state /app/output /app/work
